const mongoose = require('mongoose');

const facultySchema = new mongoose.Schema({
  name: String,
  dept: String,
  email: String,
  phone: String,
  salary: Number,
});

module.exports = mongoose.model('Faculty', facultySchema);

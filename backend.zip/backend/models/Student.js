const mongoose = require('mongoose');

const studentSchema = new mongoose.Schema({
  name: String,
  regNo: String,
  department: String,
  year: String,
  email: String,
  phone: String,
});

module.exports = mongoose.model('Student', studentSchema);

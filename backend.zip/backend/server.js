const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const Student = require('./models/Student');
const Faculty = require('./models/Faculty');

const app = express();
app.use(cors());
app.use(express.json());
// const mongoose = require('mongoose');

mongoose.connect('mongodb://127.0.0.1:27017/cmis')
  .then(() => console.log("✅ MongoDB connected successfully"))
  .catch(err => console.error("❌ MongoDB connection error:", err));

// Student Routes
app.post('/students', async (req, res) => {
  const student = new Student(req.body);
  await student.save();
  res.send(student);
});

app.get('/students', async (req, res) => {
  const students = await Student.find();
  res.send(students);
});

// Faculty Routes
app.post('/faculty', async (req, res) => {
  const faculty = new Faculty(req.body);
  await faculty.save();
  res.send(faculty);
});

app.get('/faculty', async (req, res) => {
  const faculty = await Faculty.find();
  res.send(faculty);
});

app.listen(5000, () => {
  console.log('Server running on http://localhost:5000');
});
